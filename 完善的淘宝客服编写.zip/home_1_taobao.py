#-*-encoding:utf8-*-
##author:yy zhou
"""
目标建立一个完善的客服机器人
"""
import re
import pymysql


##对询问的案件进行分类
class ClassGoods():
    question = "您好！我想请问下我的快递是哪家公司？"
    q_class = 1
    def __init__(self,question = question,q_class = q_class):
        self.question = question
        self.q_class = q_class
    def class_goods(self,x):
        try:
            rules = []
            for line in open("./rules.txt","r",encoding="utf8"):
                rules.append(line.replace("\n",""))
            for rule in rules:
                if bool(re.search(rule.split(" ")[0],x)) == True:
                    q_a = rule.split(" ")[1]
            return q_a
        except:
            print("抱歉！您的问题客服不太理解，请您重新提问，或者询问人工客服！")

##基于问题类型对数据库进行访问
class Get_Answer():
    answer = "商品已经送达"
    def __init__(self,answer = answer):
        self.answer = answer
    def sql_q_a(self,q_a,x1,x2):
        #print("q_a:",q_a)
        try:
            sql_str = "select "+q_a+" from goods"+" where account ='"+x1+"'" "and id="+x2
            conn = pymysql.connect(host='localhost', port=3306, user='root', passwd='123456', db='world', charset='utf8')
            cursor = conn.cursor()
            cursor.execute(sql_str)
            result = cursor.fetchone()
            sql_answer = "select A from answer where Q='"+q_a+"'"
            cursor.execute(sql_answer)
            result1 = cursor.fetchone()
            cursor.close()
            conn.close()
            all_answer = result1[0].replace("$",result[0])
            return all_answer
        except:
            return("抱歉！您的问题客服不太理解，请您重新提问，或者询问人工客服！")


###建立一个问答的主函数
def main():
    s1 = input("请问您的用户名是：")
    s3 = input("请问您商品的编号是：")
    try:
        while True:
            s2 = input("请问您想咨询的问题是：")
            print("s2:",s2)
            a = ClassGoods()
            class_goods1 = a.class_goods(s2)
            #print("class_goods1:",class_goods1)
            b = Get_Answer()
            s4 = b.sql_q_a(class_goods1,s1,s3)
            print(s4)
    except:
            print("您好！您的账户名出现问题，请核实账户名称。")

if __name__ == "__main__":
    print("ctrl+c can stop server!")
    main()





